from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return render(request, 'tax/index.html')


def calculate(request, number):
    return HttpResponse(f'tax = {number + (number * 0.15)}')


def taxrate(request):
    rate = 15
    return HttpResponse(f'tax rate = {rate}%')
